var express = require("express");
var router = express.Router();
var listofcourses = require("../model/courselist.model");
var path = require("path");
var fs = require("fs");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("courses", { title: "List Of Courses", listofcourses });
});

router.get("/coursedetails/:cid", function (req, res, next) {
  let theCourseId = +req.params.cid;
  let theCourse = listofcourses.find((c) => c.id === theCourseId);
  res.render("coursedetails", { theCourse,title:'Course Details' });
});

router.get("/video/:cid", (req, res) => {
  let theCourseId = +req.params.cid;
  let theCourse = listofcourses.find((c) => c.id === theCourseId);

  const range = req.headers.range;

  // get video stats
  const videopath = theCourse.introVideo;
  const videoSize = fs.statSync(videopath).size;
  console.log(videoSize);

  // range
  const CHUNK_SIZE = 10 ** 6; // 1 MB
  const start = Number(range.replace(/\D/g, ""));
  const end = Math.min(start + CHUNK_SIZE, videoSize - 1);

  // headers
  const contentLength = end - start + 1;
  const headers = {
    "Content-Range": `bytes ${start}-${end}/${videoSize}`,
    "Accept-Ranges": "bytes",
    "Content-Length": contentLength,
    "Content-Type": "video/mp4",
  };

  res.writeHead(206, headers);
  // read the video as a readableStream
  const videoStream = fs.createReadStream(videopath, { start, end });

  // stream the video as response to the client !
  videoStream.pipe(res);
});

router.post('/newcourse/:cid',(req,res)=>{
    // read the values from req.body
    //push to listofcourses
});

router.get('/course/edit/:cid',(req,res)=>{
  let theCourseId = +req.params.cid;

  let theCourse = listofcourses.find(c=>c.id === theCourseId);

  res.render('editcourse',{title:'Edit Course',theCourse});
});

router.patch('/course/save/:cid',(req,res)=>{
  let theCourseReceived = req.body; //uses express.json() middleware
  let theCourseId = +req.params.cid;
  let theCourseIndex = listofcourses.findIndex(c=>c.id === theCourseId);
  listofcourses[theCourseIndex] = {...theCourseReceived,introVideo:listofcourses[theCourseIndex].introVideo}; 
  res.json({msg:'success',theCourseReceived});
});



router.delete('/course/:cid', (req,res) => {    
if(req.params.cid){
  let theCourseId = +req.params.cid;
  let theCourseIndex = listofcourses.findIndex((c) => c.id === theCourseId);
  let deletedCourse = listofcourses.splice(theCourseIndex,1);
  if(deletedCourse){    
     res.json({deletedCourse:deletedCourse[0],msg:'success'});
}else{
  res.statusCode = 404;
  res.send('Something went wrong !'); // logging No CourseId Found !
  }
}
});
module.exports = router;
