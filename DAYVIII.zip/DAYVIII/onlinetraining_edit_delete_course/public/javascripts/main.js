$(document).ready(function(){
    $('.delete-course').on('click',function(e){               
        const id = this.id;       
        $.ajax({
            type:'DELETE',
            url:'/course/'+id,
            success:(response)=>{
                if(response.msg === 'success'){
                    alert(`${response.deletedCourse.title} deleted successfully !`);
                    window.location.href = '/';  // reload the page ! (OR in SPA) delete the item from DOM !
                }
            },
            error:(err)=>{
                alert(err)
            }
        });
    });


 $('.edit-course').on('click',function(e){               
         const id = this.id;  
        window.location.href = '/course/edit/'+id; 
    });

    $('.save-course').on('click',function(e){               
         const id = this.id;  
         e.preventDefault();
        $.ajax({
            type:'PATCH',
            url:'/course/save/'+id,
            contentType:'application/json',
            data:JSON.stringify({                
                id: parseInt($('#txtCourseId').val()),
                title:$('#txtCourseTitle').val(),
                price:$('#txtCoursePrice').val(),
                rating:$('#txtCourseRating').val(),
                likes:$('#txtCourseLikes').val(),
                imageUrl:$('#txtCourseImageUrl').val(),
                description:$('#txtCourseDesc').val(),
            }),
            success:(response)=>{
                if(response.msg === 'success'){
                    alert(`${response.theCourseReceived.title} edited successfully !`);                    
                    window.location.href = '/';  // reload the page ! (OR in SPA) delete the item from DOM !
                }
            },
            error:(err)=>{
                alert(err)
            }
        });
    });


});