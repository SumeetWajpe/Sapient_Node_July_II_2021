var fs = require("fs"); // built-in

//non-blocking code
fs.readFile("Inut.txt", function (err, dataFromFile) {
  if (err) console.log(err);
  else console.log(`Read file (Async) : ${dataFromFile}`);
});

// blocking code
// let dataFromFile = fs.readFileSync("Input.txt");
// console.log(`Read file (Sync) : ${dataFromFile}`);

console.log("Program Ended !");
