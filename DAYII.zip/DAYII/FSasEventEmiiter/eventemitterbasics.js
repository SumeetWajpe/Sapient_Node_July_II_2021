let fs = require("fs");

let readableStream = fs.createReadStream("Input.txt");
let writableStream = fs.createWriteStream("Output.txt");
let allData = "";
readableStream.on("data", function (chunk) {
  //   console.log(chunk.toString());
  console.log(">>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>");
  allData += chunk;
});

// readableStream.on("error", function (err) {

// });

readableStream.on("end", function () {
  writableStream.write(allData);
  writableStream.end();
});
