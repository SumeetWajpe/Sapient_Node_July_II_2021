let axios = require("axios").default;

let thePromise = axios.get("https://jsonplaceholder.typicode.com/users");
thePromise.then((response) => console.log(response.data));
