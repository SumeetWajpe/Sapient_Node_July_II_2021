let os = require("os");//http,fs // commonjs way of import

let toMB = function (totalBytes) {
  return Math.round(((totalBytes / 1024 / 1024) * 100) / 100);
};

console.log("Total Memory in RAM :  " + toMB(os.totalmem()));
