let Addition = require("./Math").Addition;
console.log(`The addition is : ${Addition(10, 20)}`);

// let MathModule = require("./Math");
// console.log(`The addition is : ${MathModule.Addition(10, 20)}`);
// console.log(`The product is : ${MathModule.Multiplication(10, 20)}`);
