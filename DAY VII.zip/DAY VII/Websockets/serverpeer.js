const socket = require("socket.io");
const http = require("http");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 5000;
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/html");
  fs.readFile("ClientPeer.html", function (err, data) {
    res.end(data);
  });
});

var io = socket(server);
io.sockets.on("connection", function (skt) {
  // send / emit event / msg to Client Peer !
  setInterval(() => {
    let dataToBeSent = new Date();
    skt.emit("custom_message_from_serverpeer", dataToBeSent);
  }, 2000);

  skt.on("custom_message_from_clientpeer", (dataFromClientPeer) => {
    console.log(dataFromClientPeer);
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running @ port ${port} !`);
});
