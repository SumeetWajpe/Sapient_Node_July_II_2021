const express = require("express");
const coursesRoutes = require("./coursesRoutes");
const app = express(); // represents our application
const path = require("path");

app.use(express.static("public")); // serves the static files
app.use(express.urlencoded({ extended: true })); // parses the request and creates a new object (req.body)
app.use("/", coursesRoutes); // add courses routes to the application
app.get("/", (req, res) => {
  res.sendFile("Courses.html", {
    root: path.resolve("./", "public"),
  });
});

// Last In Order
app.use((req, res) => {
  // sendFile("ErrorPage.html")
  res.send(
    "<h1 style='color:red;border:2px solid red;'>Resource Not Found ! </h1>"
  );
});

app.listen(5000, () => console.log("Server running @ port 5000 !"));
