const express = require("express");
const coursesRoutes = require("./server/coursesRoutes");
const app = express(); // represents our application

app.use("/", coursesRoutes); // add courses routes to the application
app.get("/", (req, res) => {
  res.send("<h1>Change Url to /courses to access courses data !</h1>");
  //res.sendFile("Index.html", { root: __dirname });
});

// Last In Order
app.use((req, res) => {
  // sendFile("ErrorPage.html")
  res.send(
    "<h1 style='color:red;border:2px solid red;'>Resource Not Found ! </h1>"
  );
});

app.listen(5000, () => console.log("Server running @ port 5000 !"));
