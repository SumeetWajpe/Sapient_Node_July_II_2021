const express = require("express");
const app = express(); // represents our application

app.get("/", (req, res) => {
  //   res.send("<h1>Served from Express !</h1>");
  res.sendFile("Index.html", { root: __dirname });
  //res.set("Content-Type", "application/json");
  //res.json({ message: "Data Sent using res.json()" });
});

app.get('/courses', (req,res) => {
        
});


app.listen(5000, () => console.log("Server running @ port 5000 !"));
