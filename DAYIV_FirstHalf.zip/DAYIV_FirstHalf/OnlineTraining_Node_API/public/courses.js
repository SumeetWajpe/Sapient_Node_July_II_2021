// get the data from fetch api
function FetchCourses() {
  return fetch("http://localhost:3000/courses").then((res) => res.json());
}
