const http = require("http"); // built-in module
let fs = require("fs");
let static = require("node-static");
let listofcourses = require("./model/courselist.model");

const hostname = "127.0.0.1";
const port = 3000;

var file = new static.Server("./public");

const server = http.createServer((req, res) => {
  if (req.url === "/courses" && req.method === "GET") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(listofcourses));
  } else {
    file.serve(req, res);
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
