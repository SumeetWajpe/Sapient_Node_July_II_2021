const http = require("http"); // built-in module
let fs = require("fs");
let static = require("node-static");

const hostname = "127.0.0.1";
const port = 3000;

var file = new static.Server("./public");

const server = http.createServer((req, res) => {
  file.serve(req, res);
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
