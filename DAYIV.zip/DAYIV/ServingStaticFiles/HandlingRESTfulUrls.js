const http = require("http");
const url = require("url");
const fs = require("fs");

const server = http.createServer((req, res) => {
  if (req.url == "/products" && req.method == "GET") {
    // this would come from db
    var products = [
      { id: 1, title: "LED TV", price: 40000 },
      { id: 2, title: "Laptop", price: 50000 },
    ];
    // send some JSON
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(products));
  }
});

server.listen(3000, "127.0.0.1", () => {
  console.log(`Server running at http://127.0.0.1:3000/`);
});
