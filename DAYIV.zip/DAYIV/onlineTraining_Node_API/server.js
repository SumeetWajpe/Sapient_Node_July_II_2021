const http = require("http"); // built-in module
let fs = require("fs");
let static = require("node-static");
let listofcourses = require("./model/courselist.model");

const hostname = "127.0.0.1";
const port = 3000;

var file = new static.Server("./public");

const server = http.createServer((req, res) => {
  if (req.url === "/courses" && req.method === "GET") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(listofcourses));
  } else if (req.url.match(/\/courses\/([0-9]+)/) && req.method === "GET") {
    // fetch the id from '/courses/1'
    const courseId = req.url.split("/")[2];

    // find the course and return JSON
    let theCourse = listofcourses.find((c) => c.id == courseId);
    if (theCourse) {
      res.end(JSON.stringify(theCourse));
    } else {
      res.end(JSON.stringify({ message: "Course not Found ! Try {1-5}" }));
    }
  } else {
    file.serve(req, res);
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
