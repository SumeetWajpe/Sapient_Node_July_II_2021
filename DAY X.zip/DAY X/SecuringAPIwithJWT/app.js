const express = require("express");
const app = express(); // represents our application
const jwt = require("jsonwebtoken");

app.get("/", (req, res) => {
  res.send("<h1>Served from Express !</h1>");
});
// use the username & password provided from the request object & verified db
app.get("/login", (req, res) => {
  const user = {
    id: 1,
    name: "Aniket",
    email: "aniket@gmail.com",
  };

  jwt.sign({ user }, "appsecretkey", (err, token) => {
    res.json({ token }); // will not be done here but accompany as a response object
  });
});

// /secured must allow to send response only if user authenticates !
app.get("/secured", verifyToken, (req, res) => {
  jwt.verify(req.token, "appsecretkey", (err, authData) => {
    if (err) {
      res.sendStatus(403);
    } else {
      res.json({ message: "You are in a secured area !", authData });
    }
  });
});

// custom middleware
//verify jwt token
function verifyToken(req, res, next) {
  // Get auth header
  // Authorization: Bearer <access_token>
  const bearerHeader = req.headers["authorization"];

  // check if bearerHeader is undefined !
  if (typeof bearerHeader !== "undefined") {
    // authorized !
    const bearer = bearerHeader.split(" ");
    const token = bearer[1];
    req.token = token;
    // call next thing (middleware/handle the request)
    next();
  } else {
    // Forbidden
    res.sendStatus(403);
  }
}

app.listen(5000, () => console.log("Server running @ port 5000 !"));
