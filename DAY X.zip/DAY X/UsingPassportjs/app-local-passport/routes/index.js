var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", ensureAuthentication, function (req, res, next) {
  res.render("index", { title: "Express" });
});
router.get("/secured", ensureAuthentication, function (req, res, next) {
  res.render("secured");
});

router.get("/logout", function (req, res) {
  req.logout();
  res.redirect("/login");
});
// should come from a diff module
function ensureAuthentication(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect("/failed");
}

router.get("/failed", function (req, res, next) {
  res.render("failed");
});

module.exports = router;
