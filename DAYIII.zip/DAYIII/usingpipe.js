let fs = require("fs");

let readableStream = fs.createReadStream("Input.txt");
let writableStream = fs.createWriteStream("Output.txt");

readableStream.pipe(writableStream);

