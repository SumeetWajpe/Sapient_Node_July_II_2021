let ItemIterator = require("./customEventEmitter").ItemIterator;
// subscriber
let e = ItemIterator(10);
e.on("start", () => {
  console.log("Started..");
});

e.on("item", (theCount) => {
  console.log("Received : " + theCount);
});

e.on("error", (theCount) => {
  console.log("Ended with Error : " + theCount);
});

e.on("finish", (theFinalCount) => {
  console.log("Ended with final count : " + theFinalCount);
});
