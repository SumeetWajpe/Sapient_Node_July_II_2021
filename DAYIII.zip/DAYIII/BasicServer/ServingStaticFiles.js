const http = require("http"); // built-in module
let fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  fs.readFile(__dirname + req.url, (err, fileContents) => {
      if (err) {
          res.writeHead(404);
          res.end(JSON.stringify(err))
    }
    else {
      res.statusCode = 200;
      res.end(fileContents);
    }
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
