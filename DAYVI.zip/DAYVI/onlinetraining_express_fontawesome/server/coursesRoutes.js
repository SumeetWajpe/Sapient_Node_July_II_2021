const express = require("express");
const path = require("path");
let router = express.Router();
let listofcourses = require("../model/courselist.model");

router.route("/courses").get((req, res) => {
  res.json(listofcourses);
});

router.route("/newcourse").post((req, res) => {
  console.log(req.body);
  listofcourses.push(req.body);
  res.sendFile("Courses.html", {
    root: path.resolve("./", "public"),
  });
});

module.exports = router;
