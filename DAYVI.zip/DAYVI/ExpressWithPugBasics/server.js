const express = require("express");
const app = express(); // represents our application
const path = require("path");
const indexRouter = require("./routes/index");
const productsRouter = require("./routes/products");

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));
app.use("/", indexRouter);
app.use("/", productsRouter);

app.get("/", (req, res) => {
  res.send("use /index for using pug file !");
});

app.listen(5000, () => console.log("Server running @ port 5000 !"));
