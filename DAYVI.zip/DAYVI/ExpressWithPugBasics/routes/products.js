const express = require("express");
let router = express.Router();

router.route("/products").get((req, res) => {
  res.render("products", {
    productsData: [
      { id: 1, name: "LED TV" },
      { id: 2, name: "Laptop" },
    ],
  });
});
module.exports = router;
