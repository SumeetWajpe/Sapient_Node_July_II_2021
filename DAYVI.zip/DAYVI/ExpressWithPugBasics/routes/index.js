const express = require("express");
let router = express.Router();

router.route("/index").get((req, res) => {
  res.render("index", { message: "Using Pug as View Engine !" });
});
module.exports = router;
