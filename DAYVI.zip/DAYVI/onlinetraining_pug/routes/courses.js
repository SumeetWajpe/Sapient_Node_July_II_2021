var express = require("express");
var router = express.Router();
var listofcourses = require("../model/courselist.model");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("courses", { title: "List Of Courses", listofcourses });
});

router.get("/coursedetails/:cid", function (req, res, next) {
  let theCourseId = +req.params.cid;
  let theCourse = listofcourses.find((c) => c.id === theCourseId);
  res.render("coursedetails", { theCourse });
});

module.exports = router;
