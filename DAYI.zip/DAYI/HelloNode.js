console.log("Hello World !");

setTimeout(function () {
  console.log("Got executed after 0 seconds !");
}, 0);
setTimeout(function () {
  console.log("Got executed after 500 milli seconds !");
}, 500);

console.log("Program ended..");

