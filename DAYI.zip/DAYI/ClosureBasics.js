function Outer() {
  let msg = "Inner executed !";
  return function () {
    console.log(msg);
  };
}
let Inner = Outer();
Inner();
