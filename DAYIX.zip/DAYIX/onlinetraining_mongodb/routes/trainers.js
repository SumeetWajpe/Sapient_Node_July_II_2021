var express = require("express");
var router = express.Router();
var Trainers = require("../controllers/trainers.controller");

/* GET trainers listing. */
router.get("/", async function (req, res, next) {
  // get the data from mongodb
  let url = "mongodb://localhost:27017";

  // using then()
  // Trainers.GetAllTrainers(
  //     url,
  //     "onlinetrainingdb",
  //     "trainers"
  // ).then((trainers) => {
  //     res.render("trainers", { trainers, title: "Meet Our Trainers" });
  // });

  // async await
  try {
    let trainers = await Trainers.GetAllTrainers(
      url,
      "onlinetrainingdb",
      "trainers"
    );
    res.render("trainers", { trainers, title: "Meet Our Trainers" });
  } catch (error) {
    console.log(error);
    res.writeHead(404);
    res.send("Error !");
  }
});

module.exports = router;
