const { MongoClient } = require("mongodb");

class Trainers {
  static allTrainers;
  static GetAllTrainers(url, db, coll) {
    // if allTrainers exists !!!! Don't use this when data is realtime | live
    // if (this.allTrainers) {
    //   return this.allTrainers;
    // }
    return new Promise((resolve, reject) => {
      MongoClient.connect(url, { useNewUrlParser: true }, (err, dbconn) => {
        let collection = dbconn.db(db).collection(coll);
        collection.find({}).toArray((err, result) => {
          if (err) {
            console.log(err);
            reject(err);
          } else {
            // allTrainers = result;
            resolve(result);
          }
        });
      });
    });
  }
}

module.exports = Trainers;

// MongoClient.connect(
//     url,
//     { useNewUrlParser: true },
//     (err, dbconn) => {
//       if (err) {
//         console.log(err);
//       } else {
//         let collection = dbconn.db(db).collection(coll);
//         collection.find({}).toArray((err, result) => {
//           if (err) console.log(err);
//           else {
//             return result;
//           }
//         });
//       }
//     }
//   );
