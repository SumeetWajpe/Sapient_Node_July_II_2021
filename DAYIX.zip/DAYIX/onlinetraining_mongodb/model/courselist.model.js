let listofcourses = [
  {
    id: 1,
    title: "React",
    price: 5000,
    likes: 400,
    rating: 5,
    introVideo: "./videos/React.mp4",
    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    description:
      "React is a free and open-source front-end JavaScript library for building user interfaces or UI components. It is maintained by Facebook and a community of individual developers and companies. React can be used as a base in the development of single-page or mobile applications.",
  },
  {
    id: 2,
    title: "Redux",
    price: 4000,
    likes: 600,
    rating: 5,
    introVideo: "./videos/Redux.mp4",

    imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
    description:
      "Redux is an open-source JavaScript library for managing application state. It is most commonly used with libraries such as React or Angular for building user interfaces. Similar to Facebook's Flux architecture, it was created by Dan Abramov and Andrew Clark",
  },
  {
    id: 3,
    title: "Node",
    price: 6000,
    likes: 900,
    rating: 4,
    introVideo: "./videos/Node.mp4",
    imageUrl:
      "https://www.cloudsavvyit.com/p/uploads/2019/07/2350564e.png?width=1198&trim=1,1&bg-color=000&pad=1,1",
    description:
      "Node.js is an open-source, cross-platform, back-end JavaScript runtime environment that runs on the V8 engine and executes JavaScript code outside a web browser. ",
  },
  {
    id: 4,
    title: "Angular",
    price: 5000,
    likes: 200,
    rating: 3,
    introVideo: "./videos/Angular.mp4",

    imageUrl:
      "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",
    description:
      "Angular is a TypeScript-based free and open-source web application framework led by the Angular Team at Google and by a community of individuals and corporations. Angular is a complete rewrite from the same team that built AngularJS.",
  },
  {
    id: 5,
    title: "Flutter",
    price: 7000,
    likes: 700,
    rating: 4,
    introVideo: "./videos/Flutter.mp4",

    imageUrl: "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
    description:
      'Flutter is an open-source UI software development kit created by Google. It is used to develop cross platform applications for Android, iOS, Linux, Mac, Windows, Google Fuchsia, and the web from a single codebase. The first version of Flutter was known as codename "Sky" and ran on the Android operating system. ',
  },
];

module.exports = listofcourses;

// db.courses.insert([
//   { title: "Flutter", price: 5000, rating: 5 },
//   { title: "Node", price: 6000, rating: 4 },
// ]);

// insert 5 documents for trainers
// {id,name,avatarUrl,rating,aboutMe,location}

// db.trainers.insert([
//   {
//     _id:1,
//     name: 'Mojombo',
//     avatarUrl: 'https://avatars.githubusercontent.com/u/1?v=4',
//     rating: 5,
//     aboutMe:`My name is Daniel Neumann and this is my personal blog or better my personal knowledge base where I am writing down my thoughts all around Microsoft Azure, Kubernetes and Cloud Native technologies.

//     I am working for LeanIX as a Staff Software Engineer in the Platform Operations team.`

//   },
//   {
//     _id:2,
//     name: 'Defunkt',
//     avatarUrl: 'https://avatars.githubusercontent.com/u/2?v=4',
//     rating: 3,
//     aboutMe:`My name is Defunkt and this is my personal blog or better my personal knowledge base where I am writing down my thoughts all around Microsoft Azure, Kubernetes and Cloud Native technologies.

//     I am working for LeanIX as a Staff Software Engineer in the Platform Operations team.`

//   },
//   {
//     _id:3,
//     name: 'Pjhyett',
//     avatarUrl: 'https://avatars.githubusercontent.com/u/3?v=4',
//     rating: 5,
//     aboutMe:`My name is pjhyett and this is my personal blog or better my personal knowledge base where I am writing down my thoughts all around Microsoft Azure, Kubernetes and Cloud Native technologies.

//     I am working for LeanIX as a Staff Software Engineer in the Platform Operations team.`

//   },
//   {
//     _id:4,
//     name: 'Wycats',
//     avatarUrl: 'https://avatars.githubusercontent.com/u/4?v=4',
//     rating: 4,
//     aboutMe:`My name is wycats and this is my personal blog or better my personal knowledge base where I am writing down my thoughts all around Microsoft Azure, Kubernetes and Cloud Native technologies.

//     I am working for LeanIX as a Staff Software Engineer in the Platform Operations team.`

//   },
//   {
//     _id:5,
//     name: 'Ezmobius',
//     avatarUrl: 'https://avatars.githubusercontent.com/u/5?v=4',
//     rating: 4,
//     aboutMe:`My name is wycats and this is my personal blog or better my personal knowledge base where I am writing down my thoughts all around Microsoft Azure, Kubernetes and Cloud Native technologies.

//     I am working for LeanIX as a Staff Software Engineer in the Platform Operations team.`

//   }
// ]);
